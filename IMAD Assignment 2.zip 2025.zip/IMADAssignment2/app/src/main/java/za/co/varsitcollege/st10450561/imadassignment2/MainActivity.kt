package za.co.varsitcollege.st10450561.imadassignment2

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// =============================
// MainActivity.kt
// =============================
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val welcomeText = findViewById<TextView>(R.id.txtWelcome)
        val startButton = findViewById<Button>(R.id.btnStart)

        startButton.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            startActivity(intent)
        }
    }
}

// =============================
// QuizActivity.kt
// =============================
class QuizActivity : AppCompatActivity() {

    private val questions = arrayOf(
        "Nelson Mandela was the president in 1994",
        "The Great Wall of China is visible from space",
        "World War I started in 1939",
        "The Eiffel Tower is located in Italy",
        "The Cold War ended in 1991"
    )

    private val answers = arrayOf(true, false, false, false, true)
    private var score = 0
    private var index = 0
    private lateinit var currentQuestion: TextView
    private lateinit var feedbackText: TextView
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        currentQuestion = findViewById(R.id.txtQuestion)
        feedbackText = findViewById(R.id.txtFeedback)
        nextButton = findViewById(R.id.btnNext)

        val btnTrue = findViewById<Button>(R.id.btnTrue)
        val btnFalse = findViewById<Button>(R.id.btnFalse)

        loadQuestion()

        btnTrue.setOnClickListener { checkAnswer(true) }
        btnFalse.setOnClickListener { checkAnswer(false) }

        nextButton.setOnClickListener {
            index++
            if (index < questions.size) {
                loadQuestion()
                feedbackText.text = ""
            } else {
                val intent = Intent(this, ScoreActivity::class.java).apply {
                    putExtra("score", score)
                    putExtra("questions", questions)
                    putExtra("answers", answers)
                }
                startActivity(intent)
                finish()
            }
        }
    }

    private fun loadQuestion() {
        currentQuestion.text = questions[index]
    }

    private fun checkAnswer(userAnswer: Boolean) {
        if (userAnswer == answers[index]) {
            score++
            feedbackText.text = "Correct!"
        } else {
            feedbackText.text = "Incorrect"
        }
    }
}

// =============================
// ScoreActivity.kt
// =============================
class ScoreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score)

        val score = intent.getIntExtra("score", 0)
        val questions = intent.getStringArrayExtra("questions")
        val answers = intent.getBooleanArrayExtra("answers")

        val txtScore = findViewById<TextView>(R.id.txtScore)
        val txtFeedback = findViewById<TextView>(R.id.txtFeedback)
        val btnReview = findViewById<Button>(R.id.btnReview)
        val btnExit = findViewById<Button>(R.id.btnExit)

        txtScore.text = "Your Score: $score / 5"
        txtFeedback.text = if (score >= 3) "Great job!" else "Keep practising!"

        btnReview.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Review Answers")

            val reviewMsg = StringBuilder()
            if (questions != null && answers != null) {
                for (i in questions.indices) {
                    reviewMsg.append("${i + 1}. ${questions[i]}\nAnswer: ${if (answers[i]) "True" else "False"}\n\n")
                }
            }

            builder.setMessage(reviewMsg.toString())
            builder.setPositiveButton("OK", null)
            builder.show()
        }

        btnExit.setOnClickListener {
            finishAffinity() // Closes the app
        }
    }
}

